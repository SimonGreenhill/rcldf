# CLDF directory

This directory contains the dataset formatted as CLDF Wordlist.
